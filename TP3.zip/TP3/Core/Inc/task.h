/*
 * task.h
 *
 *  Created on: Oct 24, 2025
 *      Author: Local User
 */

#ifndef INC_TASK_H_
#define INC_TASK_H_

void taskLED();
void taskButton();
void taskScreen();



#endif /* INC_TASK_H_ */
