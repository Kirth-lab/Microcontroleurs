/*
 * task.c
 *
 *  Created on: Oct 24, 2025
 *      Author: Local User
 */

#include "main.h"
#include "task.h"
#include "led.h"
#include <stdio.h>


// ******************************* taskLED - MOTIFS ************************

#define LED_BAR_SIZE 8


static LED led_bar[8]={{0,LED_0_GPIO_Port,LED_0_Pin},{0,LED_1_GPIO_Port,LED_1_Pin},
		{0,LED_2_GPIO_Port,LED_2_Pin},{0,LED_3_GPIO_Port,LED_3_Pin},
		{0,LED_4_GPIO_Port,LED_4_Pin},{0,LED_5_GPIO_Port,LED_5_Pin},
		{0,LED_6_GPIO_Port,LED_6_Pin},{0,LED_7_GPIO_Port,LED_7_Pin}};

static int globalDelayInMs = 200;

typedef struct motif_type{
	int size;
	int* motif;
	char* name;
} MOTIF_TYPE;

int upDownMotif[]= {0, 128, 192, 224, 240, 248, 252, 254, 255, 252, 248, 240, 224, 192, 128};
int cheniUpMotif[] = {1,2,4,8,16,32,64,128};
int cheniDownMotif[] = {128, 64, 32, 16, 8, 4, 2, 1};

const MOTIF_TYPE upDown = {16, upDownMotif, "Up Down"};
const MOTIF_TYPE cheniUp = {8, cheniUpMotif, "K 2000"};
const MOTIF_TYPE cheniDown = {8, cheniDownMotif, "K -2000"};

const MOTIF_TYPE* tableau_motif[3] = {&upDown, &cheniUp, &cheniDown};

static int index_tableau_motif=0;


void taskLED(){
	int numero_motif = (HAL_GetTick()/globalDelayInMs)%(tableau_motif[index_tableau_motif]-> size);
	//printf("Led ON\n\r");
//ED_Test_All();

	printf("numero_motif = %d\n\r", numero_motif);

	HAL_GPIO_WritePin(led_bar[numero_motif/2].port
							  ,led_bar[numero_motif/2].pinNumber, GPIO_PIN_SET);


}


// ******************************* taskButton ************************




void taskButton(){
	printf("Button ON\n\r");
}

void taskScreen(){
	printf("Screen ON\n\r");
}



