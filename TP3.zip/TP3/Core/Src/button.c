/*
 * button.c
 *
 *  Created on: Jun 14, 2024
 *      Author: nicohaas57
 */

#include "main.h"
#include "button.h"

typedef struct button {
	int isOn;
	int hasBeenPressed;
	GPIO_TypeDef* port;
	uint16_t pinNumber;
}BUTTON;

typedef enum direction{CENTER, DOWN, RIGHT, UP, LEFT}DIRECTION;

static BUTTON joystick[5] = { {0,0,BTN_CENTER_GPIO_Port,BTN_CENTER_Pin}, {0,0,BTN_BOTTOM_GPIO_Port,BTN_BOTTOM_Pin},
							 {0,0,BTN_RIGHT_GPIO_Port,BTN_RIGHT_Pin}, {0,0,BTN_TOP_GPIO_Port,BTN_TOP_Pin},
							 {0,0,BTN_LEFT_GPIO_Port,BTN_LEFT_Pin}
};

int BUTTON_Get_Value(DIRECTION direction) {
	return joystick[direction].isOn;
}

int BUTTON_Get_Pressed(DIRECTION direction) {
	return joystick[direction].hasBeenPressed;
}

void BUTTON_Update() {
	int new_v[5] = {0};
	for (int i = 0; i < 5; i++){
		new_v[i] = HAL_GPIO_ReadPin(joystick[i].port, joystick[i].pinNumber);
		joystick[i].hasBeenPressed = (1-joystick[i].isOn)*new_v[i];
		joystick[i].isOn = new_v[i];
	}
}

