/*
 * tele.c
 *
 *  Created on: Sep 18, 2025
 *      Author: Local User
 */

#include <stdio.h>
#include "tele.h"
#include "main.h"

#include <stm32l4xx_hal.h>
// extern UART_HandleTypeDef huart2;

static int led = 0 ;

void loop_k(void){
	  while (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13)==1){

	  }
		  led = 1 - led ;
		  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, led);
		  HAL_Delay(250);

	  while(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13)==0){

	  }
	  /*
	  char testSwitch(int led){
	  	  		switch(led){
	  	  		case 0 : printf("Switch pressed. LED ON");
	  	  		break;
	  	  		case 1 : printf("Switch pressed. LED OFF");
	  	  		break;
	  	  		  		}
	  	  		  	}
	  	  		  	-
	  	  	printf("Etat %c \n\r", testSwitch(led));
	  	  	*/


	  }




