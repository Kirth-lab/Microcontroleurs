/*
 * tele.c
 *
 *  Created on: Sep 18, 2025
 *      Author: Local User
 */

#include "corrige.h"
#include <stm32l4xx_hal.h>
extern UART_HandleTypeDef huart2;
void setup(void){
    // insert the setup here, it will be run once.
}


void loop(void){
    // This code will run indefinitely.

	static int status_led=0; // non réinitialisés
	static int compteur=0;

	while(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13)==1){
	}
	// Tant que le bouton n'est pas appuyé
	status_led=1-status_led;
	compteur++;
	printf("Compteur = %d, led=%d \n\r",compteur,status_led);
	HAL_GPIO_WritePin(GPIOA,GPIO_PIN_5,status_led);
	while(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_13)==0){
	}



 //   HAL_UART_Transmit(&huart2,"Test \n\r",8,-1);
}
