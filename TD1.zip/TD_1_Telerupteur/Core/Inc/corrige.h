/*
 * tele.h
 *
 *  Created on: Sep 18, 2025
 *      Author: Local User
 */

#ifndef INC_CORRIGE_H_
#define INC_CORRIGE_H_

#include <stdio.h>

void setup(void);
void loop(void);

#endif /* INC_CORRIGE_H_ */
