/*
 * tele.h
 *
 *  Created on: Sep 18, 2025
 *      Author: Local User
 */

#ifndef INC_TELE_H_
#define INC_TELE_H_

// Prototypes //


//char testSwitch(int led);
void loop();


#endif /* INC_TELE_H_ */
