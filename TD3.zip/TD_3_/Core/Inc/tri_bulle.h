/*
 * tri_bulle.h
 *
 *  Created on: Oct 22, 2025
 *      Author: Local User
 */

#ifndef INC_TRI_BULLE_H_
#define INC_TRI_BULLE_H_

int sortArray(int* toSort, int* sorted, int size);

#endif /* INC_TRI_BULLE_H_ */
