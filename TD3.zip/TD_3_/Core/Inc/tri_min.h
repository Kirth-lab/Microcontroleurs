/*
 * tri_min.h
 *
 *  Created on: Sep 26, 2025
 *      Author: Local User
 */

#ifndef INC_TRI_MIN_H_
#define INC_TRI_MIN_H_

void loop(void);
int getMinPosition();
void displayArray();



#endif /* INC_TRI_MIN_H_ */
