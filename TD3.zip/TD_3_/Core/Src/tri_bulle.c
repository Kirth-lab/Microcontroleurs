/*
 * tri_bulle.c
 *
 *  Created on: Oct 22, 2025
 *      Author: Local User
 */

#include "tri_bulle.h"
#define ARRAY_SIZE

int sortArray(int* toSort, int* sorted, int size){
	int sortedPosition[ARRAY_SIZE] = {0};
	int min = 0;
	for (int i=0; i < size; i ++){
		toSort[i] = sorted[i];
	}
	for (int i=size-1; i>0; i--){
		for (int j=0; j<i; j++){
			if (sorted[j+1] < sorted[j]){
				int temp = sorted[j];
				sorted[j]=sorted[j+1];
				sorted[j+1]=temp;
			}
		}
	}
}
