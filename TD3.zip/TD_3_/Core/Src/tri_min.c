/*
 * tri_min.c
 *
 *  Created on: Sep 26, 2025
 *      Author: Local User
 */



#include <stm32l4xx_hal.h>
#include <stdio.h>
#include "tri_min.h"


// ********************************************************

// toBeIgnored = [0 1 0 0 1 1 1 0 0 1 1 0 0 0 0]

int getMinPosition(int* array, int* toBeIgnored, int size){
	int i = 0 ;
	int pos = 0 ;
	int* pmin = array[0];

	for (i = 0 ; i < size ; i ++){
		if (array[i] < *pmin) {
			*pmin = array[i];
			toBeIgnored[i] = 0;
			// On a un minimum à la position i, on donne la valeur 0 dans le tableau toBeIgnored
		}
		else{
			toBeIgnored[i] = 1;
			// On n'a pas un minimum à la position i, on donne la valeur 1 dans le tableau toBeIgnored
		}
	}

	for (i = 0 ; i < size ; i ++){
		if (toBeIgnored[i] == 0){
			pos = i;
		}
	}

	return pos ;

}

#define ARRAY_SIZE 15
int arrayTest[ARRAY_SIZE] = {0, 1, -3, 10, -1, 0, 0, 0, 0, 12, 1024, 10, 45, 6, 4};

void loop(void){
	  	int ignored[ARRAY_SIZE] = {0};
	  	int index = 0;
	  	index = getMinPosition(arrayTest, ignored, ARRAY_SIZE);
	  	printf("First min at : %d \n\r", index);
	  	ignored[index] = 1;
	  	index = getMinPosition(arrayTest, ignored, ARRAY_SIZE);
	  	printf("Second min at : %d \n\r", index);
	  	}

void displayArray(int array[ARRAY_SIZE]){
	int i = 0 ;
	for (i = 0; i < ARRAY_SIZE; i ++ ){
		printf("array[%d] = %d \n\r", i, array[i]);
	}
}

