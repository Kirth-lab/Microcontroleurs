/*
 * code.c
 *
 *  Created on: Sep 19, 2025
 *      Author: Local User
 */

// *****  Includes  *****
#include <stm32l4xx_hal.h>
#include "code.h"
#include <stdio.h>


// ****** USER CODE ******

 /*
void setup(void){
	int var = 100;
	printf("Var : %d, %x, %c \n\r", var, var, var);

	var ++;
	printf("Apres modif : %d, %x, %c \n\r", var, var, var);

	uint8_t c;
	for(c=0; c<=254; c++){
		printf("c = %d %x %c \n\r", c, c, c);
	}
		printf("c = %d %x %c \n\r", c, c, c);
		c++;
		printf("c = %d %x %c \n\r", c, c, c);

}


int globale = 100;
void fonction(int par){
	int locale = 5;
	locale++;
	globale++;
	par++;
	printf("*** Interieur de la fonction *** \n\r Valeur de locale : %d \t de globale : %d \t de parametre : %d\n\r", locale, globale, par);
	// printf("\n");
}


void setup(void){
	int locale = 10;
	int par = 20;
	printf("*** Setup avant appel de fonction ***\n\r Valeur de locale : %d \t de globale : %d \t de parametre : %d \n\r", locale, globale, par);
	fonction(par);
	printf("*** Setup apres appel de fonction ***\n\r Valeur de locale : %d \t de globale : %d \t de parametre : %d \n\r", locale, globale, par);
}

void loop(void){

}
*/


void stupid_fct(int stupid_var){
	stupid_var++ ;

}

void another_fct(void){
	int x = 0;
	stupid_fct(x);
	printf("Valeur de x : %d \n", x);
}

void not_so_stupid_fct(){
	int x_2 = 0;
	++ x_2 ;
	stupid_fct(x_2);
	printf("Valeur de x_2 : %d \n", x_2);

}

void fct_upgraded(){
	int x_3 = 0;
	int* px_3 = &x_3;
	*px_3 = 1;
	printf("Valeur de x_3 : %d \n", x_3);

}

/*
#define ARRAY_SIZE 10


void setup(void){
	setvbuf(stdin, NULL, _IONBF, 0);
}

void displayArray(int array[ARRAY_SIZE]){
	int i;
	for (i = 0; i < ARRAY_SIZE; i++){
	printf("array[%d] = %d\n\r", i, array[i]);
	}
}

void loop(void){
	int array[ARRAY_SIZE] = {0};
	int index;
	while (1){
	scanf("%d", &index);
	array[index] = 1;
	displayArray(array);
	}

}
*/
