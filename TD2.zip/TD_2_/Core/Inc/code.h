/*
 * code.h
 *
 *  Created on: Sep 19, 2025
 *      Author: Local User
 */

#ifndef INC_CODE_H_
#define INC_CODE_H_

// void setup(void);
// void loop(void);
//void fonction();

//void displayArray();

void stupid_fct();
void another_fct();
void not_so_stupid_fct();
void fct_upgraded();
#define stdin
// extern int globale ;


#endif /* INC_CODE_H_ */
