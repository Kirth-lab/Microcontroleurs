/*
 * utils.h
 *
 *  Created on: Apr 26, 2024
 *      Author: antotauv
 */

#ifndef INC_TP1_H_
#define INC_TP1_H_

void setup();
void loop();
//extern UART_HandleTypeDef huart1;
//extern UART_HandleTypeDef huart2;
int fillBuffer(char* buffer, int size);
int isGPGGA(char* frame);
int extractChecksum(char* buffer);
int calculateChecksum(char* buffer);
int checkFrame(char* buffer);

char* trouverVirgule_1(char *frame);
float getLatitude(char* frame);

#define BUFFER_SIZE 128
#endif /* INC_TP1_H_ */
