/*
 * utils.c
 *
 *  Created on: Sep 25, 2023
 *      Author: antotauv
 */

// *************************** INCLUDES *********************************
#include "utils.h"
#include "main.h"
#include "utils.h"
#include "ssd1315.h"
#include "fonts.h"
//#include "cityDataBase.h"
#include <stdio.h>
#include <string.h>


// ******************************* SETUP *******************************
void setup(){
	printf ("TP1 ENSEA by A.T. \r\n");
	ssd1315_Init();
	ssd1315_Clear(SSD1315_COLOR_BLACK);
	ssd1315_Draw_String(0,0,"GPS Lab",&Font_16x26);
	ssd1315_Refresh();
	HAL_GPIO_WritePin(GPS_ENN_GPIO_Port,GPS_ENN_Pin,1);
}

//*************************** BUFFER *******************************************

//static char buffer[BUFFER_SIZE]={0};

HAL_StatusTypeDef HAL_UART_Abort(UART_HandleTypeDef *huart);
HAL_StatusTypeDef HAL_UART_Receive(UART_HandleTypeDef *huart, uint8_t *pData, uint16_t Size, uint32_t Timeout);
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;

#define BUFFER_MAX_SIZE 128
char buffer[BUFFER_MAX_SIZE]; //globale


int fillBuffer(char* buffer, int size){
	int i = 0;
	int total = 0;
	char received_char;
	for(i=0; i < size; i++){
		buffer[i] = 0;
	}

	do{
		while(HAL_UART_Receive(&huart1, (uint8_t *)&received_char, 1, 0)!=HAL_OK);
	}while(received_char != '$');

	do{
		*buffer = received_char;
		while(HAL_UART_Receive(&huart1, (uint8_t *)&received_char, 1, 0)!=HAL_OK);
		total ++;
		buffer ++; //valeur jamais remise à sa valeur initiale car locale
	}while(received_char != '\n');

	*buffer = received_char;
	return total;
}

// ********************************* LOOP *********************************
/*
void loop(){
	int size = fillBuffer(buffer, BUFFER_MAX_SIZE);
	printf("Just received : %s\r\n",buffer);
}
*/

void loop_1() {
		  char received_char;
		  while(HAL_UART_Receive(&huart1, (uint8_t *)&received_char, 1, 0)!=HAL_OK){}
		  HAL_UART_Transmit(&huart2, (uint8_t *) &received_char, 1, HAL_MAX_DELAY);
	  }

void loop_2(){
	char buffer[BUFFER_MAX_SIZE];
	int size;
	while(1){
		size = fillBuffer(buffer, BUFFER_MAX_SIZE);
		printf("Received %d char : %s \n\r", size, buffer);
	}
}

// ******************************** CHECKSUM *****************************

int isGPGGA(char* frame){
	if(strcmp(frame, "$GPGGA")==0){
		return 1;
	}
	else{
		return -1 ;
	}
}

int extractChecksum(char* buffer){
	while(*buffer != '*'){
		buffer ++;
	}
	return (buffer[1]&0x0f)*16 + (buffer[2]&0x0f);
}

int calculateChecksum(char* buffer){
	int checksum = 0;
	buffer ++;
	while(*buffer != '*'){
		checksum = checksum^(*buffer);
		buffer ++;
	}

	return checksum;
}


void loop_3(){
	int size = fillBuffer(buffer, BUFFER_MAX_SIZE);
	printf("Just received %d bytes \r\n", size);
	if (isGPGGA(buffer)==1){
		printf("Trame GPGGA \r\n");
		printf("Checksum -> calculated %x \t extract %x \r\n", calculateChecksum(buffer), extractChecksum(buffer));

	}
}

int checkFrame(char* buffer){
	int checksum = calculateChecksum(buffer);
	int extract = extractChecksum(buffer);
	if ( (checksum == extract) && (isGPGGA(buffer) == 1) ){
			return 1;
	}
	else{
			return 0;
	}
}


void loop_4(){
	char buffer[BUFFER_MAX_SIZE];
	if (checkFrame(buffer) == 1){
		printf("La trame est correcte.");
	}
	else{
		printf("La trame est fautive");
	}
}

//**************** Récupération de l'information au format flottant ***************

// Trame correcte : 67

char* trouverVirgule_1(char *frame){
	while (*frame != ","){
		frame ++;
	}
	char* new_frame =  ++frame;
	char* useful_frame = trouverVirgule_1(new_frame);
	return useful_frame;
}
// On a la frame sans la partie " $GPGGA,084440.477,"


char* conversionHex(char *frame){
	char *x = trouverVirgule_1(*frame) ;
	char *new_frame_2 = {0} ;
	int i = 0;
	int size = fillBuffer(buffer, BUFFER_MAX_SIZE);
	for (i=0; i < 8; i ++){
		x[i] = new_frame_2[i]&0xf;
	}
	printf("%s", x);

}

float* calcul_latitude(char* x){
	int i = 0;
	int NS = 0;
	int lat_1 = 0;
	int lat_2 = 0;
	char test ;
	while (test != "."){
		x ++;
		for (i=0; i < 8; i ++){
			lat_1 = [ 10*x[0] + x[1] + (1/60)*(10*x[2] + x[3] + 0.1*x[5] + 0.01*x[6] + 10**(-2)*x[7]) ]
		}
		int NS = x[8];
		lat_2 = (-1)**(NS)*lat_1 ;
	}
}






