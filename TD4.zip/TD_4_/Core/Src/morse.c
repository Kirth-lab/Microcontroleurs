/*
 * morse.c
 *
 *  Created on: Oct 22, 2025
 *      Author: Local User
 */
#include "main.h"
#include "morse.h"

#include <string.h>


const MORSE_LETTRE alphabet[ALPHABET_SIZE] =
{
		{'A',".-"},{'B',"-..."},{'C',"-.-."},
		{'D',"-.."},{'E',"."},{'F',"..-."},
		{'G',"--."},{'H',"...."},{'I',".."},
		{'J',".---"},{'K',"-.-"},{'L',".-.."},
		{'M',"--"},{'N',"-."},{'O',"---"},
		{'P',".--."},{'Q',"--.-"},{'R',".-."},
		{'S',"..."},{'T',"-"},{'U',"..-"},
		{'V',"...-"},{'W',".--"},{'X',"-..-"},
		{'Y',"-.--"},{'Z',"--.."},
		{'1',".----"},{'2',"..---"},{'3',"...--"},
		{'4',"....-"},{'5',"....."},{'6',"-...."},
		{'7',"--..."},{'8',"---.."},{'9',"----."},{'0',"-----"}
};

char lookupInBaseFromCode(char* code){
	for(int i=0; i < ALPHABET_SIZE; i++){
		if(strcmp(code, alphabet[i].code)==0){
			return alphabet[i].letter;
		}
		else{
			return 0;
		}
	}
}

char* lookupInBaseFromLetter(char letter){
	for(int i =0; i < ALPHABET_SIZE; i++){
		if(letter == alphabet[i].letter){
			return alphabet[i].code;
		}
		else{
			return 0;
		}
	}
}

char waitForInput(char previousInput){
	int start = HAL_GetTick(); // à partir de RUN

	while (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == 0){ // =0 : appuis courts
		if (HAL_GetTick() - start > 200){
			return '-';
		}
		else if (HAL_GetTick() - start < 200){
			return '.';  //appui court
		}
	}

	while (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13) == 1){ // =1 : appuis longs
		if (((HAL_GetTick()-start)>1000) && (previousInput!=' ')){
			return ' ';
		}
	}
}


/*
char registerMorse(char* code, char previousInput){
	char input = waitForInput(previousInput);
	int i;
	for (i=0; i<10; i++){
		if (input == ' ' ){
		local_tab[].morse_code = code;
		}
	}

}
*/



