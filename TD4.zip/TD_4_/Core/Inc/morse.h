/*
 * morse.h
 *
 *  Created on: Oct 22, 2025
 *      Author: Local User
 */

#ifndef INC_MORSE_H_
#define INC_MORSE_H_


#include "main.h"
typedef struct morse_lettre{
	char letter;
	char* code;
} MORSE_LETTRE;

#define ALPHABET_SIZE 36

extern const MORSE_LETTRE alphabet[ALPHABET_SIZE];


char lookupInBaseFromCode(char* code);
char* lookupInBaseFromLetter(char letter);

char waitForInput(char previousInput);



typedef struct local_tab{
	char* morse_code ;
} LOCAL_TAB;

#endif /* INC_MORSE_H_ */
