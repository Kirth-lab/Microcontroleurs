/*
 * encoder.c
 *
 *  Created on: Nov 13, 2025
 *      Author: Local User
 */

#include "main.h"
#include "encoder.h"
#include "stepperMotor.h"
#include "tim.h"
#include <stdio.h>
#include <stdlib.h>


/* Rappel de la structure
 typedef struct encoder{
	TIM_HandleTypeDef * htim;
	int32_t max_value;
	int32_t min_value;
}ENCODER;
 */

static ENCODER encoder ;

uint32_t channel = TIM_CHANNEL_ALL ;

void encoder_init(TIM_HandleTypeDef *htim_param, int32_t min, int32_t max){
	encoder.htim = htim_param;
	encoder.min_value = min;
	encoder.max_value = max;
	HAL_TIM_Encoder_Start(htim_param, channel);
	encoder.htim -> Instance -> CNT = 0;
}


int32_t encoder_read(){
	int32_t sat_min = encoder.min_value  ;
	int32_t sat_max = encoder.max_value  ;
	if (encoder.htim -> Instance -> CNT < sat_min){
		return sat_min;
		encoder.htim -> Instance -> CNT=sat_min;
	}
	if(encoder.htim -> Instance -> CNT > sat_max){
		return sat_max;
		encoder.htim -> Instance -> CNT=sat_max;
	}
	return encoder.htim -> Instance -> CNT;
}

/*
 typedef struct stepperMotor{
	TIM_HandleTypeDef * htim_pwm;
	uint32_t pwm_channel_number;
	GPIO_TypeDef * gpio_direction;
	uint16_t gpio_direction_pin;
	GPIO_TypeDef * gpio_ms1;
	uint16_t gpio_ms1_pin;
	GPIO_TypeDef * gpio_ms2;
	uint16_t gpio_ms2_pin;
	GPIO_TypeDef * gpio_enable;
	uint16_t gpio_enable_pin;
	uint8_t speed;
	uint32_t step_target;
	uint32_t step_actual;
}STEPPERMOTOR;

void init_stepper(TIM_HandleTypeDef * htim_pwm_p, uint32_t pwm_channel_number_p,
					GPIO_TypeDef * gpio_direction_p, uint16_t gpio_direction_pin_p,
					GPIO_TypeDef * gpio_ms1_p, uint16_t gpio_ms1_pin_p,
					GPIO_TypeDef * gpio_ms2_p, uint16_t gpio_ms2_pin_p,
					GPIO_TypeDef * gpio_enable_p, uint16_t gpio_enable_pin_p);
 */

static STEPPERMOTOR stepperMotor;

void init_stepper(TIM_HandleTypeDef * htim_pwm_p, uint32_t pwm_channel_number_p,
					GPIO_TypeDef * gpio_direction_p, uint16_t gpio_direction_pin_p,
					GPIO_TypeDef * gpio_ms1_p, uint16_t gpio_ms1_pin_p,
					GPIO_TypeDef * gpio_ms2_p, uint16_t gpio_ms2_pin_p,
					GPIO_TypeDef * gpio_enable_p, uint16_t gpio_enable_pin_p){
	stepperMotor.htim_pwm = htim_pwm_p;
	stepperMotor.pwm_channel_number = pmw_channel_number_p;
	stepperMotor.gpio_direction = gpio_direction_p;
	stepperMotor.gpio_direction_pin = gpio_direction_pin_p;
	stepperMotor.gpio_ms1 = gpio_ms1_p;
	stepperMotor.gpio_ms1_pin = gpio_ms1_pin_p;
	stepperMotor.gpio_ms2 = gpio_ms2_p;
	stepperMotor.gpio_ms2_pin = gpio_ms2_pin_p;
	stepperMotor.gpio_enable = gpio_enable_p;
	stepperMotor.gpio_enable_pin = gpio_enable_pin_p;

	HAL_TIM_PMW_Start(stepperMotor.htim_pwm, channel);
	HAL_GPIO_WritePin(stepperMotor.gpio_direction,stepperMotor.gpio_direction_pin,0);
	HAL_GPIO_WrtiePin(stepperMotor.gpio_ms1,stepperMotor.gpio_ms1_pin,0);
	HAL_GPIO_WritePin(stepperMotor.gpio_ms2,stepperMotor.gpio_ms2_pin, 0);
	HAL_GPIO_WritePin(stepperMotor.gpio_enable,stepperMotor.gpio_enable_pin, 1);

	stepperMotor.htim_pwm->Instance->CCR1=stepperMotor.htim_pwm->Instance->ARR/2;
	HAL_TIM_PWM_Start(stepperMotor.htim_pwm,stepperMotor.pwm_channel_number);

}

void launch_stepper(int speed){
	int abs_speed_value = abs(speed);
	abs_speed_value = (abs_speed_value>8)?8:abs_speed_value;
	stepperMotor.speed=speed;
	const uint16_t period_counter_value[8]={1599,1399,1199,999,799,599,399,299};
	if (abs_speed_value==0){
		stepperMotor.htim_pwm->Instance->CCR1=0;
		}
	else{
		HAL_GPIO_WritePin(stepperMotor.gpio_enable, stepperMotor.gpio_enable_pin,0);
		HAL_GPIO_WritePin(stepperMotor.gpio_direction, stepperMotor.gpio_direction_pin,(speed>0)?1:0);
		stepperMotor.htim_pwm->Instance->ARR=period_counter_value[abs_speed_value-1];
		stepperMotor.htim_pwm->Instance->CCR1=stepperMotor.htim_pwm->Instance->ARR/2;
		}
}

float get_speed(){
	if (stepperMotor.speed==0) {
		return 0;
	}
	int32_t period_value = ((stepperMotor.htim_pwm->Instance->ARR+1)*80)/(stepperMotor.htim_pwm->Instance);
	int32_t one_turn = period_value * 1600;
	float speed = (((stepperMotor.speed>0)?1:-1)*(60 * 1000000))/one_turn;
	return speed;
	}
